信息传输中继 —— 服务器部署包
============================================================

这个包用于在一台全新的 Linux 服务器上部署中继服务。

【先看这个】
  本包只装服务器，不含使用文档。文档在 Windows 上看的，
  放在「配置生成器.zip」里，共 4 份：
      01-快速开始.txt     从零到能传，约 20 分钟，含阿里云逐步操作
      02-服务器部署.txt   本包的详细部署说明（本文是精简版）
      03-使用教程.txt     日常使用、费用、安全
      04-常见问题.txt     出错怎么办
  手边只有这个 tar.gz 的话，照下面做也能装完。

一、准备工作
------------

1. 一台 Linux 服务器（Ubuntu 20.04+ / Debian 11+ / CentOS 8+ / Alibaba Cloud Linux）
   最低配置：1 核 1 GB 内存即可（中继不转发文件内容，只传指令）

2. 一个阿里云 OSS Bucket
   控制台：https://oss.console.aliyun.com/
   点「创建 Bucket」，填：
       Bucket 名称    自己起，全阿里云唯一，只能小写字母数字和短横线
       地域           选离你服务器近的，例如华东1（杭州）
       存储类型       标准存储
       读写权限       私有        ← 必须，不能选公共读
       冗余类型       本地冗余 LRS
   创建完记下两件事：Bucket 名、地域对应的 Endpoint
   例：华东1（杭州）的 Endpoint 是 oss-cn-hangzhou.aliyuncs.com

3. 一个 RAM 子账号的 AccessKey（不要用主账号）
   控制台：https://ram.console.aliyun.com/users
   a. 点「创建用户」，只勾「OpenAPI 调用访问」，不要勾控制台登录
   b. 创建完立刻会显示 AccessKey ID 和 AccessKey Secret
      Secret 只显示这一次，关掉就再也看不到，务必当场复制保存
   c. 给这个用户授权：点「添加权限」，选「自定义策略」，
      策略内容用本文件最后一节的 JSON（先把 BUCKET名 换成你的）
   d. 授权后生效要等约 1 分钟

4. 云服务器安全组放行你选的端口（默认 8080）
   控制台 → 实例 → 安全组 → 配置规则 → 入方向 → 手动添加：
       端口范围   8080/8080
       授权对象   0.0.0.0/0   （或只填你自己的 IP，更安全）
   不放行的话，服务器上能跑，但浏览器打不开。

二、部署（3 条命令）
--------------------

把 relay-deploy.tar.gz 上传到服务器（用 scp / Xftp / 宝塔都行），然后：

    tar xzf relay-deploy.tar.gz
    cd relay-deploy
    sudo bash server/deploy/install.sh

脚本会依次问你 7 个问题，带 * 的必填：

    公网 IP 或域名 *     填你服务器的公网 IP，例：121.0.0.1
                         有域名且已解析就填域名，例：relay.example.com
    端口                 直接回车＝8080
    密码（至少12位）*     控制台的登录密码，自己定，记住它
    再输一次 *           同上，防打错
    设备密钥             直接回车＝自动生成32位随机串（推荐）
    Endpoint *           OSS 地域地址，直接回车＝华东1杭州
                         oss-cn-hangzhou.aliyuncs.com
    Bucket 名 *          第一步创建的 Bucket 名字
    AccessKeyId *        RAM 子账号的 AccessKey ID
    AccessKeySecret *    RAM 子账号的 AccessKey Secret（输入时屏幕不显示）

脚本然后自动完成这些事，不用你手动做：
    · 检查 Python 版本（要求 3.8+）
    · 复制程序到 /opt/server
    · 写配置文件并设为 600 权限（里面有 AK，不能让别人读到）
    · 创建 relay 系统用户（不给登录 shell）
    · 装成 systemd 服务并设开机自启
    · 配 OSS 生命周期规则（7 天自动清理）和 CORS
    · 真连一次 OSS 做自检，配置错了当场报出来
    · 配置防火墙放行端口

全程约 1 分钟。如果某一步报错，脚本会停下并打印原因。

三、验证
--------

安装脚本最后会打印：

    控制台地址 : http://你的IP:8080
    登录密码   : 你填的密码
    设备密钥   : 你填的或自动生成的32位串

三样都记下来，后面生成传输助手要用到「地址」和「设备密钥」。

用浏览器打开控制台地址，输入密码能登录就成功了。

打不开的排查顺序：
    1. 服务器上跑 curl -s http://127.0.0.1:8080/ 有返回吗？
       有 → 服务正常，问题在安全组／防火墙，看第三步第 4 条
       没有 → 服务没起来，跑 systemctl status relay 看原因
    2. 安全组入方向放行 8080 了吗
    3. 云厂商的服务器还要确认「防火墙」没拦（阿里云只有安全组）

如果自检报 OSS 错误，通常是这三种：
    AccessDenied     AK 权限不够，检查 RAM 策略里的 BUCKET名 换对了没
    NoSuchBucket     Bucket 名写错，或 Endpoint 和桶不在同一地域
    InvalidAccessKeyId  AK 复制错了，注意别带空格

四、给目标电脑生成传输助手
--------------------------

在 Windows 电脑上用「配置生成器」：

    1. 解压 配置生成器.zip
    2. 记事本打开 配置.txt，填：
           服务器地址=你的IP
           设备密钥=上面打印的设备密钥
    3. 双击 生成传输助手.bat
    4. 把生成的 传输助手.bat 发到目标电脑

五、常用命令
------------

    systemctl status relay              查看状态
    systemctl restart relay             重启
    journalctl -u relay -n 50 --no-pager   看日志
    vi /opt/server/config.json          改配置（改完要重启）

六、RAM 权限策略（推荐）
-----------------------

在 https://ram.console.aliyun.com/policies 创建自定义策略，
脚本编辑模式粘贴下面内容（把 3 处 BUCKET名 换成你的）：

{
  "Version": "1",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "oss:PutObject",
        "oss:GetObject",
        "oss:DeleteObject",
        "oss:AbortMultipartUpload",
        "oss:ListParts",
        "oss:ListObjects"
      ],
      "Resource": [
        "acs:oss:*:*:BUCKET名",
        "acs:oss:*:*:BUCKET名/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "oss:PutBucketLifecycle",
        "oss:GetBucketLifecycle",
        "oss:DeleteBucketLifecycle",
        "oss:PutBucketCORS",
        "oss:GetBucketCORS"
      ],
      "Resource": [
        "acs:oss:*:*:BUCKET名"
      ]
    }
  ]
}

注意第二个 Statement：这 5 条是「桶级」权限，只作用于桶本身
（Resource 结尾不带 /*），install.sh 用它自动配置生命周期和跨域规则。
少了它们，自检的最后一步会报 PutBucketLifecycle 拒绝，
安装脚本会提示「生命周期规则应用失败」——不影响传文件，
但对象就不会 7 天自动清理了，得你自己去控制台点。

七、费用说明
------------

    上传到 OSS   免费
    从 OSS 下载  约 0.5 元/GB
    OSS 存储     约 0.12 元/GB/月
    ECS          你自己的机器

OSS 的生命周期规则（自动清理）和跨域规则（CORS）由 install.sh 自动配好，
不用你手动去控制台设置：

    保留天数      7 天（到期自动删除对象，未完成的分片同样 7 天后清理）
    跨域 CORS     自动按你的控制台地址写入

想改保留天数，编辑 /opt/server/config.json 的 lifecycle 段（days 字段），然后：

    sudo -u relay python3 /opt/server/tools/setup_oss.py --apply

注意是「删除」不是「归档」，到期文件不可恢复。
想长期保留就把 enabled 设成 false，代价是存储费会一直涨。

另外在费用中心设置「余额预警」（比如 10 元），
欠费会导致所有 OSS 操作返回 UserDisable。
